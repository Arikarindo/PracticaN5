cmake_minimum_required(VERSION 3.16)

project(Practica4 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_executable(Practica4
    main.cpp
    Enrutador.h
    Enrutador.cpp
    Red.h
    Red.cpp
)

if(MSVC)
    target_compile_options(Practica4 PRIVATE /W4)
else()
    target_compile_options(Practica4 PRIVATE -Wall -Wextra)
endif()

# Copia topologia.txt al directorio de compilacion para que Qt Creator lo encuentre al ejecutar
configure_file(
    ${CMAKE_CURRENT_SOURCE_DIR}/topologia.txt
    ${CMAKE_CURRENT_BINARY_DIR}/topologia.txt
    COPYONLY
)
