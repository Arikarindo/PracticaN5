#include "Enrutador.h"

#include <algorithm>
#include <functional>
#include <iostream>
#include <limits>
#include <queue>
#include <utility>

using namespace std;

// Constructor por defecto
Enrutador::Enrutador() : id('\0') {}

// Constructor parametrizado
Enrutador::Enrutador(char id) : id(id) {}

char Enrutador::getId() const { return id; }

void Enrutador::agregarVecino(char vecinoId, int costo) {
  vecinos[vecinoId] = costo;
}

void Enrutador::eliminarVecino(char vecinoId) { vecinos.erase(vecinoId); }

void Enrutador::modificarCostoVecino(char vecinoId, int costo) {
  auto it = vecinos.find(vecinoId); // Busca el vecino
  if (it != vecinos.end()) {        // Si existe
    it->second = costo;
  }
}

bool Enrutador::tieneVecino(char vecinoId) const {
  return vecinos.find(vecinoId) != vecinos.end();
}

// Referencia solo lectura
const map<char, int> &Enrutador::getVecinos() const { return vecinos; }

void Enrutador::actualizarTabla(
    const map<char, map<char, int>> &topologia) {
  tablaEnrutamiento.clear();

  if (topologia.find(id) == topologia.end()) {
    return;
  }

  const int INF = numeric_limits<int>::max();
  map<char, int> distancias;
  map<char, char> predecesores;

  for (const auto &par : topologia) {
    distancias[par.first] = INF;
  }
  distancias[id] = 0;

  using ParCola = pair<int, char>;
  priority_queue<ParCola, vector<ParCola>, greater<ParCola>> pq; // Min-heap por costo
  pq.push(make_pair(0, id));

  while (!pq.empty()) {
    int distActual = pq.top().first;
    char u = pq.top().second;
    pq.pop();

    if (distActual > distancias[u]) { // Descarta entrada vieja
      continue;
    }

    auto itNodo = topologia.find(u);
    if (itNodo == topologia.end()) {
      continue;
    }

    for (const auto &arista : itNodo->second) { // Relaja aristas vecinas
      char v = arista.first;
      int peso = arista.second;
      if (peso < 0) {
        continue;
      }
      if (distancias[u] != INF && distancias[u] + peso < distancias[v]) {
        distancias[v] = distancias[u] + peso;
        predecesores[v] = u;
        pq.push(make_pair(distancias[v], v));
      }
    }
  }

  for (const auto &par : topologia) { // Reconstruye cada ruta
    char destino = par.first;
    EntradaRuta entrada;

    if (distancias[destino] == INF) {
      entrada.costo = -1;
    } else {
      entrada.costo = distancias[destino];
      char actual = destino;
      while (actual != id) {
        entrada.camino.push_back(actual);
        auto itPred = predecesores.find(actual);
        if (itPred == predecesores.end()) {
          entrada.camino.clear();
          entrada.costo = -1;
          break;
        }
        actual = itPred->second;
      }
      if (entrada.costo != -1) {
        entrada.camino.push_back(id);
        reverse(entrada.camino.begin(), entrada.camino.end()); // Invierte orden origen->destino
      }
    }

    tablaEnrutamiento[destino] = entrada;
  }
}

int Enrutador::getCosto(char destino) const {
  auto it = tablaEnrutamiento.find(destino);
  if (it == tablaEnrutamiento.end()) {
    return -1;
  }
  return it->second.costo;
}

vector<char> Enrutador::getCamino(char destino) const {
  auto it = tablaEnrutamiento.find(destino);
  if (it == tablaEnrutamiento.end()) {
    return vector<char>();
  }
  return it->second.camino;
}

void Enrutador::imprimirTabla() const {
  cout << "\n=== Tabla de enrutamiento del nodo '" << id << "' ===\n";
  cout << "Destino\tCosto\tCamino\n";
  cout << "----------------------------------------\n";
  for (const auto &par : tablaEnrutamiento) {
    char destino = par.first;
    const EntradaRuta &entrada = par.second;
    cout << "  " << destino << "\t";
    if (entrada.costo == -1) {
      cout << "INF\tInalcanzable\n";
    } else {
      cout << entrada.costo << "\t";
      for (size_t i = 0; i < entrada.camino.size(); ++i) {
        cout << entrada.camino[i];
        if (i + 1 < entrada.camino.size()) {
          cout << " -> ";
        }
      }
      cout << "\n";
    }
  }
}
