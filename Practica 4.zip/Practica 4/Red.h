#ifndef RED_H
#define RED_H

#include "Enrutador.h"
#include <map>
#include <vector>

class Red {
private:
    std::map<char, Enrutador> enrutadores; // Vertices del grafo

    void recalcularTodasLasTablas();

public:
    Red() = default;

    bool existeEnrutador(char id) const;
    bool agregarEnrutador(char id);
    bool removerEnrutador(char id);

    bool agregarEnlace(char a, char b, int costo);
    bool removerEnlace(char a, char b);
    bool actualizarCosto(char a, char b, int costo);

    bool cargarTopologia(const char* nombreArchivo);
    bool guardarTopologia(const char* nombreArchivo) const;

    void generarRedAleatoria(int numNodos, int probabilidad, int costoMax);

    int costoEnvio(char origen, char destino) const;
    std::vector<char> caminoEnvio(char origen, char destino) const;

    void imprimirTablaEnrutador(char id) const;
    void imprimirMatrizCostos() const;
    void imprimirTopologia() const;
    void limpiar();
};

#endif // RED_H
