#ifndef ENRUTADOR_H
#define ENRUTADOR_H

#include <map>
#include <vector>

// Fila tabla enrutamiento
struct EntradaRuta {
    int costo;
    std::vector<char> camino;
};

class Enrutador {
private:
    char id;
    std::map<char, int> vecinos;                   // Vecinos y costos
    std::map<char, EntradaRuta> tablaEnrutamiento; // Caminos mas cortos

public:
    Enrutador();
    explicit Enrutador(char id);

    char getId() const;

    void agregarVecino(char vecinoId, int costo);
    void eliminarVecino(char vecinoId);
    void modificarCostoVecino(char vecinoId, int costo);
    bool tieneVecino(char vecinoId) const;
    const std::map<char, int>& getVecinos() const;

    void actualizarTabla(const std::map<char, std::map<char, int>>& topologia);

    int getCosto(char destino) const;
    std::vector<char> getCamino(char destino) const;
    void imprimirTabla() const;
};

#endif // ENRUTADOR_H
