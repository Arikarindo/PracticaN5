#include "Red.h"

#include <iostream>
#include <limits>
#include <vector>

using namespace std;

static void limpiarBufferEntrada() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

static void mostrarMenu() {
    cout << "\n========================================\n";
    cout << "   SIMULADOR DE RED DE ENRUTADORES\n";
    cout << "========================================\n";
    cout << "1. Cargar topologia desde archivo (.txt)\n";
    cout << "2. Guardar topologia actual en archivo (.txt)\n";
    cout << "3. Generar topologia aleatoria\n";
    cout << "4. Agregar enrutador\n";
    cout << "5. Eliminar enrutador\n";
    cout << "6. Agregar enlace\n";
    cout << "7. Eliminar enlace\n";
    cout << "8. Modificar costo de enlace\n";
    cout << "9. Ver tabla de enrutamiento de un enrutador\n";
    cout << "10. Ver matriz de costos y topologia\n";
    cout << "11. Consultar costo y ruta optima entre dos nodos\n";
    cout << "0. Salir\n";
    cout << "Seleccione una opcion: " << flush; // Fuerza salida consola
}

int main() {
    Red red;
    int opcion = -1;

    do {
        mostrarMenu();
        if (!(cin >> opcion)) {
            if (cin.eof()) { // Sale al cerrar
                cout << "\nFin de la entrada. Saliendo...\n";
                break;
            }
            cout << "Entrada invalida. Intente nuevamente.\n";
            limpiarBufferEntrada();
            continue;
        }

        switch (opcion) {
            case 1: {
                char nombreArchivo[256];
                cout << "Nombre del archivo (ej. topologia.txt): ";
                cin >> nombreArchivo;
                if (red.cargarTopologia(nombreArchivo)) {
                    cout << "Topologia cargada exitosamente desde '" << nombreArchivo << "'.\n";
                } else {
                    cout << "Error: no se pudo abrir el archivo '" << nombreArchivo << "'.\n";
                }
                break;
            }
            case 2: {
                char nombreArchivo[256];
                cout << "Nombre del archivo de salida (ej. salida.txt): ";
                cin >> nombreArchivo;
                if (red.guardarTopologia(nombreArchivo)) {
                    cout << "Topologia guardada en '" << nombreArchivo << "'.\n";
                } else {
                    cout << "Error: no se pudo escribir en '" << nombreArchivo << "'.\n";
                }
                break;
            }
            case 3: {
                int numNodos = 0;
                int probabilidad = 0;
                int costoMax = 0;
                cout << "Numero de enrutadores (1 - 52): ";
                cin >> numNodos;
                cout << "Probabilidad de enlace entre pares (0 - 100): ";
                cin >> probabilidad;
                cout << "Costo maximo por enlace (>= 1): ";
                cin >> costoMax;
                if (cin.fail()) {
                    cout << "Parametros invalidos.\n";
                    limpiarBufferEntrada();
                } else {
                    red.generarRedAleatoria(numNodos, probabilidad, costoMax);
                    cout << "Red aleatoria generada (guardada en 'topologia_aleatoria.txt').\n";
                }
                break;
            }
            case 4: {
                char id = '\0';
                cout << "Identificador del nuevo enrutador (un caracter, ej. E): ";
                cin >> id;
                if (red.agregarEnrutador(id)) {
                    cout << "Enrutador '" << id << "' agregado.\n";
                } else {
                    cout << "El enrutador '" << id << "' ya existe.\n";
                }
                break;
            }
            case 5: {
                char id = '\0';
                cout << "Identificador del enrutador a eliminar: ";
                cin >> id;
                if (red.removerEnrutador(id)) {
                    cout << "Enrutador '" << id << "' eliminado y tablas actualizadas.\n";
                } else {
                    cout << "El enrutador '" << id << "' no existe.\n";
                }
                break;
            }
            case 6: {
                char a = '\0';
                char b = '\0';
                int costo = 0;
                cout << "Enrutador origen: ";
                cin >> a;
                cout << "Enrutador destino: ";
                cin >> b;
                cout << "Costo del enlace (> 0): ";
                cin >> costo;
                if (cin.fail()) {
                    cout << "Costo invalido.\n";
                    limpiarBufferEntrada();
                } else if (red.agregarEnlace(a, b, costo)) {
                    cout << "Enlace (" << a << " <-> " << b << ", costo " << costo << ") agregado.\n";
                } else {
                    cout << "No se pudo agregar el enlace. Verifique que ambos nodos existan, sean distintos y costo > 0.\n";
                }
                break;
            }
            case 7: {
                char a = '\0';
                char b = '\0';
                cout << "Enrutador origen: ";
                cin >> a;
                cout << "Enrutador destino: ";
                cin >> b;
                if (red.removerEnlace(a, b)) {
                    cout << "Enlace (" << a << " <-> " << b << ") eliminado.\n";
                } else {
                    cout << "No se pudo eliminar el enlace. Verifique que exista.\n";
                }
                break;
            }
            case 8: {
                char a = '\0';
                char b = '\0';
                int costo = 0;
                cout << "Enrutador origen: ";
                cin >> a;
                cout << "Enrutador destino: ";
                cin >> b;
                cout << "Nuevo costo (> 0): ";
                cin >> costo;
                if (cin.fail()) {
                    cout << "Costo invalido.\n";
                    limpiarBufferEntrada();
                } else if (red.actualizarCosto(a, b, costo)) {
                    cout << "Costo del enlace (" << a << " <-> " << b << ") actualizado a " << costo << ".\n";
                } else {
                    cout << "No se pudo actualizar el costo. Verifique que el enlace exista y costo > 0.\n";
                }
                break;
            }
            case 9: {
                char id = '\0';
                cout << "Identificador del enrutador: ";
                cin >> id;
                red.imprimirTablaEnrutador(id);
                break;
            }
            case 10: {
                red.imprimirTopologia();
                red.imprimirMatrizCostos();
                break;
            }
            case 11: {
                char origen = '\0';
                char destino = '\0';
                cout << "Enrutador origen: ";
                cin >> origen;
                cout << "Enrutador destino: ";
                cin >> destino;

                int costo = red.costoEnvio(origen, destino);
                if (costo == -1) {
                    cout << "No existe ruta entre '" << origen << "' y '" << destino << "'.\n";
                } else {
                    vector<char> camino = red.caminoEnvio(origen, destino);
                    cout << "Costo minimo de '" << origen << "' a '" << destino << "': " << costo << "\n";
                    cout << "Camino optimo: ";
                    for (size_t i = 0; i < camino.size(); ++i) {
                        cout << camino[i];
                        if (i + 1 < camino.size()) {
                            cout << " -> ";
                        }
                    }
                    cout << "\n";
                }
                break;
            }
            case 0:
                cout << "Saliendo del simulador...\n";
                break;
            default:
                cout << "Opcion no valida.\n";
                break;
        }
    } while (opcion != 0);

    return 0;
}
