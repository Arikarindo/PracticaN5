#include "Red.h"

#include <cstdlib>
#include <ctime>
#include <fstream>
#include <iostream>

using namespace std;

void Red::recalcularTodasLasTablas() {
  map<char, map<char, int>> topologia;
  for (const auto &par : enrutadores) {
    topologia[par.first] = par.second.getVecinos(); // Recopila grafo global
  }
  for (auto &par : enrutadores) {
    par.second.actualizarTabla(topologia);
  }
}

bool Red::existeEnrutador(char id) const {
  return enrutadores.find(id) != enrutadores.end();
}

bool Red::agregarEnrutador(char id) {
  if (existeEnrutador(id)) {
    return false;
  }
  enrutadores.emplace(id, Enrutador(id)); // Inserta nuevo vertice
  recalcularTodasLasTablas();
  return true;
}

bool Red::removerEnrutador(char id) {
  auto it = enrutadores.find(id);
  if (it == enrutadores.end()) {
    return false;
  }

  enrutadores.erase(it);
  for (auto &par : enrutadores) {
    par.second.eliminarVecino(id);
  }

  recalcularTodasLasTablas();
  return true;
}

bool Red::agregarEnlace(char a, char b, int costo) {
  if (a == b || costo <= 0) {
    return false;
  }
  auto itA = enrutadores.find(a);
  auto itB = enrutadores.find(b);
  if (itA == enrutadores.end() || itB == enrutadores.end()) { // Valida nodos existentes
    return false;
  }

  itA->second.agregarVecino(b, costo);
  itB->second.agregarVecino(a, costo);
  recalcularTodasLasTablas();
  return true;
}

bool Red::removerEnlace(char a, char b) {
  auto itA = enrutadores.find(a);
  auto itB = enrutadores.find(b);
  if (itA == enrutadores.end() || itB == enrutadores.end()) { // Valida nodos existentes
    return false;
  }
  if (!itA->second.tieneVecino(b)) { // Valida enlace existente
    return false;
  }

  itA->second.eliminarVecino(b);
  itB->second.eliminarVecino(a);
  recalcularTodasLasTablas();
  return true;
}

bool Red::actualizarCosto(char a, char b, int costo) {
  if (a == b || costo <= 0) {
    return false;
  }
  auto itA = enrutadores.find(a);
  auto itB = enrutadores.find(b);
  if (itA == enrutadores.end() || itB == enrutadores.end()) { // Valida nodos existentes
    return false;
  }
  if (!itA->second.tieneVecino(b)) { // Valida enlace existente
    return false;
  }

  itA->second.modificarCostoVecino(b, costo);
  itB->second.modificarCostoVecino(a, costo);
  recalcularTodasLasTablas();
  return true;
}

bool Red::cargarTopologia(const char *nombreArchivo) {
  ifstream archivo(nombreArchivo);
  if (!archivo.is_open()) {
    return false;
  }

  limpiar();

  char origen = '\0';
  char destino = '\0';
  int costo = 0;

  while (archivo >> origen >> destino >> costo) {
    if (origen == destino || costo <= 0) {
      continue;
    }
    if (!existeEnrutador(origen)) {
      enrutadores.emplace(origen, Enrutador(origen));
    }
    if (!existeEnrutador(destino)) {
      enrutadores.emplace(destino, Enrutador(destino));
    }
    enrutadores[origen].agregarVecino(destino, costo);
    enrutadores[destino].agregarVecino(origen, costo);
  }

  archivo.close();
  recalcularTodasLasTablas();
  return true;
}

bool Red::guardarTopologia(const char *nombreArchivo) const {
  ofstream archivo(nombreArchivo);
  if (!archivo.is_open()) {
    return false;
  }

  for (const auto &par : enrutadores) {
    char u = par.first;
    const map<char, int> &vecinos = par.second.getVecinos();
    for (const auto &arista : vecinos) {
      char v = arista.first;
      if (u < v) { // Evita aristas duplicadas
        archivo << u << ' ' << v << ' ' << arista.second << '\n';
      }
    }
  }

  archivo.close();
  return true;
}

void Red::generarRedAleatoria(int numNodos, int probabilidad, int costoMax) {
  if (numNodos <= 0) {
    return;
  }
  if (numNodos > 52) {
    numNodos = 52;
  }
  if (probabilidad < 0) {
    probabilidad = 0;
  }
  if (probabilidad > 100) {
    probabilidad = 100;
  }
  if (costoMax < 1) {
    costoMax = 1;
  }

  static bool semillaInicializada = false;
  if (!semillaInicializada) {
    srand(static_cast<unsigned int>(time(nullptr)));
    semillaInicializada = true;
  }

  limpiar();

  vector<char> ids;
  ids.reserve(static_cast<size_t>(numNodos)); // Preasigna memoria vector
  for (int i = 0; i < numNodos; ++i) {
    char id = (i < 26) ? static_cast<char>('A' + i)
                       : static_cast<char>('a' + (i - 26));
    ids.push_back(id);
    enrutadores.emplace(id, Enrutador(id));
  }

  for (int i = 0; i < numNodos; ++i) {
    for (int j = i + 1; j < numNodos; ++j) {
      int tirada = rand() % 100;
      if (tirada < probabilidad) {
        int costo = (rand() % costoMax) + 1;
        enrutadores[ids[i]].agregarVecino(ids[j], costo);
        enrutadores[ids[j]].agregarVecino(ids[i], costo);
      }
    }
  }

  const char *archivoTemp = "topologia_aleatoria.txt";
  if (guardarTopologia(archivoTemp)) {
    map<char, Enrutador> respaldoNodos;
    for (char id : ids) {
      respaldoNodos.emplace(id, Enrutador(id));
    }
    cargarTopologia(archivoTemp);
    for (const auto &par : respaldoNodos) { // Restaura nodos aislados
      if (!existeEnrutador(par.first)) {
        enrutadores.emplace(par.first, par.second);
      }
    }
  }

  recalcularTodasLasTablas();
}

int Red::costoEnvio(char origen, char destino) const {
  auto it = enrutadores.find(origen);
  if (it == enrutadores.end() || !existeEnrutador(destino)) {
    return -1;
  }
  return it->second.getCosto(destino);
}

vector<char> Red::caminoEnvio(char origen, char destino) const {
  auto it = enrutadores.find(origen);
  if (it == enrutadores.end() || !existeEnrutador(destino)) {
    return vector<char>();
  }
  return it->second.getCamino(destino);
}

void Red::imprimirTablaEnrutador(char id) const {
  auto it = enrutadores.find(id);
  if (it == enrutadores.end()) {
    cout << "El enrutador '" << id << "' no existe en la red.\n";
    return;
  }
  it->second.imprimirTabla();
}

void Red::imprimirMatrizCostos() const {
  if (enrutadores.empty()) {
    cout << "La red esta vacia.\n";
    return;
  }

  cout << "\n=== Matriz de costos minimos ===\n\t";
  for (const auto &par : enrutadores) {
    cout << par.first << '\t';
  }
  cout << "\n";

  for (const auto &fila : enrutadores) {
    cout << fila.first << '\t';
    for (const auto &col : enrutadores) {
      int c = fila.second.getCosto(col.first);
      if (c == -1) {
        cout << "-\t";
      } else {
        cout << c << '\t';
      }
    }
    cout << "\n";
  }
}

void Red::imprimirTopologia() const {
  if (enrutadores.empty()) {
    cout << "La red esta vacia.\n";
    return;
  }

  cout << "\n=== Topologia actual (enlaces directos) ===\n";
  for (const auto &par : enrutadores) {
    cout << "Enrutador " << par.first << " -> ";
    const auto &vecinos = par.second.getVecinos();
    if (vecinos.empty()) {
      cout << "(sin vecinos)";
    } else {
      for (const auto &v : vecinos) {
        cout << "[" << v.first << ": " << v.second << "] ";
      }
    }
    cout << "\n";
  }
}

void Red::limpiar() { enrutadores.clear(); }
